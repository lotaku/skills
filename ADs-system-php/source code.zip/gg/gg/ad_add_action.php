<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<?php
//数据库信息
include 'mysqlconnect.php';
//设置SQL查询语句编码，解决中文乱码问题；
mysql_query('SET NAMES UTF8');


?>
<?php

$destination_folder="uploadimg/"; //上传文件路径

if( isset($_POST['submit']) )
{
	
	$file=$_FILES['upload_name'];
	$pic_link=$_POST['pic_link'];
	$pic_place=$_POST['pic_place'];
	//获得文件夹名字
	//echo $_FILES['upload_name']['name'];f
	//检查图片类型
	//echo $_FILES['upload_name']['type']
	
	//判断图片大小是否符合所申请的版位
	
	//获得图片地址
	/*$pinfo=pathinfo($file["name"]);
	echo $pinfo['dirname']."<br />";
	echo $pinfo['basename']."<br />";
	echo $pinfo['extension']."<br />";
	echo $file['tmp_name']."<br />";*/
	
	//获取上传的文件名，临时的；
	$filename=$file["tmp_name"];
	//自定义文件名和保存目录
	$pinfo=pathinfo($file["name"]);
	$ftype=$pinfo['extension'];
	$destination = $destination_folder.time().".".$ftype;
    if (file_exists($destination) && $overwrite != true)
    {
        echo "同名文件已经存在了";
        exit;
    }

    if(!move_uploaded_file ($filename, $destination))
    {
        echo "移动文件出错";
        exit;
    }
	//测试输出图片地址
	//echo $destination;
	
	}
	$mysql_query="INSERT INTO Images (pic_address,pic_url,pic_place) VALUES ('$destination','$pic_link','$pic_place')";
	if(mysql_query("$mysql_query"))
	{
		include "ad_add_success.php";
		}else
	{
		include "ad_add_false.php";
		}
	
	//mysql_query("INSERT INTO Images (pic_address,pic_url) VALUES ('$destination','$pic_link')")   or die ("Can't Perform Query");

?>
</body>
</html>