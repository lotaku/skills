<?php
$MysqlHost = 'localhost';

$MysqlUser = 'root';

$MysqlPass = '';

$MysqlDb ='binary_data';
//echo "成功引入mysqlconnect.php文件";
//连接数据库服务器
mysql_connect($MysqlHost, $MysqlUser, $MysqlPass)or die ('Unable to connect to SQL Server');
//选择数据库
mysql_select_db($MysqlDb)or die ('Unable to connect Database');
?>