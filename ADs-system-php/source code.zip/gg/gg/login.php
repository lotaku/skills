<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/css.css"  type="text/css" rel="stylesheet">
<title>无标题文档</title>
</head>

<body>
<h1 align="center"><strong>登录页面</strong>
<br/> =================</h1>
<?php
include 'mysqlconnect.php';
mysql_query('SET NAMES UTF8');
?>
<form name="loginform" id="loginform" action="login_jump.php" method="post">
用户名：<input type="text" name="username" id="username" /> <br />
密码：<input type="text" name="password" id="password" /> <br />
<input type="submit" name="submit"  id="button" value="登录" />
</form>

<div id='admin_menu'   >
<a href="index.php">返回广告展示页</a>


</div>
</body>
</html>
