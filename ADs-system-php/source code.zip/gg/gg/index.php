<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "logout.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/show.css"  type="text/css" rel="stylesheet">
<link href="css/css.css"  type="text/css" rel="stylesheet">
<title>广告展示页</title>
</head>

<body>

<h1 align="center"><strong>广告展示页</strong>
<br/> =================</h1>

<?php
include 'mysqlconnect.php';


//读取数据库,
  //ad_left
$mysql_query_for_ad_1="SELECT * FROM images where pic_place='ad_1'";
$result_for_ad_1=mysql_query("$mysql_query_for_ad_1");
$ad_1= mysql_fetch_array($result_for_ad_1);
$ad_1_pic_address=$ad_1['pic_address'];
$ad_1_pic_url=$ad_1['pic_url'];
  //ad2
$mysql_query_for_ad_2="SELECT * FROM images where pic_place='ad_2'";
$result_for_ad_2=mysql_query("$mysql_query_for_ad_2");
$ad_2= mysql_fetch_array($result_for_ad_2);
$ad_2_pic_address=$ad_2['pic_address'];
$ad_2_pic_url=$ad_2['pic_url'];
  //ad3
$mysql_query_for_ad_3="SELECT * FROM images where pic_place='ad_3'";
$result_for_ad_3=mysql_query("$mysql_query_for_ad_3");
$ad_3= mysql_fetch_array($result_for_ad_3);
$ad_3_pic_address=$ad_3['pic_address'];
$ad_3_pic_url=$ad_3['pic_url'];
  //ad4
$mysql_query_for_ad_4="SELECT * FROM images where pic_place='ad_4'";
$result_for_ad_4=mysql_query("$mysql_query_for_ad_4");
$ad_4= mysql_fetch_array($result_for_ad_4);
$ad_4_pic_address=$ad_4['pic_address'];
$ad_4_pic_url=$ad_4['pic_url'];
   //ad5
$mysql_query_for_ad_5="SELECT * FROM images where pic_place='ad_5'";
$result_for_ad_5=mysql_query("$mysql_query_for_ad_5");
$ad_5= mysql_fetch_array($result_for_ad_5);
$ad_5_pic_address=$ad_5['pic_address'];
$ad_5_pic_url=$ad_5['pic_url'];
//echo  $ad_1['pic_place'];
//if($ad_1['pic_place']){
//	echo "有广告";
//	
//	}else
//	{
//		echo "没有广告";
//		}




?>

<div id="ad" >
    <div id=left>
    
        <?php
		//判断广告位 
			if($ad_1_pic_address){
	include("ad_contents/ad_left_1.php");
	}else
	{
		include("ad_contents/ad_left_default_1.php");
		}
		?>
        
        <?php 
		//判断广告位
			if($ad_2_pic_address){
	include("ad_contents/ad_left_2.php");
	}else
	{
		include("ad_contents/ad_left_default_2.php");
		}
		?>
        
        <?php 
		//判断广告位
			if($ad_3_pic_address){
	include("ad_contents/ad_left_3.php");
	}else
	{
		include("ad_contents/ad_left_default_3.php");
		}
		?>
        
        <!--<div id="ad_left">
        <a href="<?php echo $ad_1_pic_url?>" ><img src="<?php echo $ad_1_pic_address?>" /></a>
        
        </div>-->
        
        
    </div>
    <div id=right>
    	 
       <?php 
		//判断广告位
			if($ad_4_pic_address){
	include("ad_contents/ad_right_1.php");
	}else
	{
		include("ad_contents/ad_right_default_1.php");
		}
		?>
        
        <?php 
		//判断广告位
			if($ad_5_pic_address){
	include("ad_contents/ad_right_2.php");
	}else
	{
		include("ad_contents/ad_right_default_2.php");
		}
		?>
    	
    </div>
</div>
<div id='admin_menu'>
<a href="login.php">用户登录</a> 

<?php 
if($_SESSION['user']=='admin')
{	
include ('admin_menu.php');
	}

?>
</div>
</body>
</html>