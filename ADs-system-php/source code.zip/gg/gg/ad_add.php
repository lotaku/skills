<?php session_start(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/ad_add.css"  type="text/css" rel="stylesheet">
<link href="css/css.css"  type="text/css" rel="stylesheet">
<title>申请广告位</title>
</head>

<body>
<h1 align="center"><strong>添加广告</strong>
<br/> =================</h1>
<?php
//phpinfo();
?>
<?php

include 'mysqlconnect.php';

if($_SESSION['user']!='admin'){
	header('location:login.php');
	
	}
?>
<form  enctype="multipart/form-data" action="ad_add_action.php" method="post"  name="ad_add" id="ad_add" >

  <p>图片地址：
    <input name="upload_name" type="file" size="50"  /> <br />
    广告链接：<input name="pic_link" type="text" /> 
  </p>
  <p>
    广告位置：<label for="pic_place"></label>
    <select name="pic_place" id="pic_place">
      <option value="ad_1">广告位 1 </option>
      <option value="ad_2">广告位 2 </option>
      <option value="ad_3">广告位 3 </option>
      <option value="ad_4">广告位 4 </option>
      <option value="ad_5">广告位 5 </option>
      

    </select>
    <a href="img/ad_place_show.jpg">点击查看广告位图示</a><br />
    <input type="submit" name="submit"	 value="提交" />
  </p>
</form>
<div id='admin_menu'   >
<a href="login.php">用户登录</a> 
<?php 
if($_SESSION['user']=='admin')
{	
include ('admin_menu.php');
	}

?>
</div>
</body>
</html>
