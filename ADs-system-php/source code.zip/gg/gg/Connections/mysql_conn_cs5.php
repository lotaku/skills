<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_mysql_conn_cs5 = "localhost";
$database_mysql_conn_cs5 = "binary_data";
$username_mysql_conn_cs5 = "root";
$password_mysql_conn_cs5 = "";
$mysql_conn_cs5 = mysql_pconnect($hostname_mysql_conn_cs5, $username_mysql_conn_cs5, $password_mysql_conn_cs5) or trigger_error(mysql_error(),E_USER_ERROR); 
?>