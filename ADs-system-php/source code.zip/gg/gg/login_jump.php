<?php
include 'mysqlconnect.php';
mysql_query('SET NAMES UTF8');
?>
<?php
session_start();
 
	
	
	$username=$_POST["username"];
	//$mysql_query="SELECT * FROM users where name=".$_POST["username"];
	//$mysql_query="SELECT * FROM users where name='admin'";
	$mysql_query="SELECT * FROM users where name='".$username."'";
	//$mysql_query="SELECT * FROM images where pic_place='ad_1'";
	//echo $mysql_query."<br />";
	$result=mysql_query("$mysql_query");
	$result_array=mysql_fetch_array($result);
	$admin=$result_array['name'];
	$password=$result_array['password'];
	if($admin)
		{
		
		 if($password==$_POST['password'])
		 	{
				//echo '密码正确';
				$_SESSION['user']=$admin;
				header('location:index.php');
			}else
			{
				echo '密码错误！';
				
			}
		
		}else
		{
			echo "用户名不存在";
			//echo '<script> alert("用户名不存在"); </script>';
		}
	

 
?>