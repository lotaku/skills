<?php
session_start();
//$_SESSION =array();
//if(isset( $_COOKIE[session('user')] ) ){
//	setcookie(session_name(),'',time()-1);
//	}
//session_destroy();
//if(empty($_SESSION['user']) )
//{
//	echo "你已成功注销";
//	}
//	
//	header('location:index.php');
$_SESSION['user']='';
header('location:index.php');

?>