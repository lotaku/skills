<div id="ad_left">
        <a href="<?php echo $ad_3_pic_url?>" ><img src="<?php echo $ad_3_pic_address?>" /></a>
        
        </div>