<div id="ad_left">
        <a href="<?php echo $ad_2_pic_url?>" ><img src="<?php echo $ad_2_pic_address?>" /></a>
        
        </div>