<div id="ad_left">
        <div id="ad_left_default" >
        广告位_1：出售中<br />
        宽：680px  高：130px
        </div>
        
        </div>