<div id="ad_left">
        <a href="<?php echo $ad_1_pic_url?>" ><img src="<?php echo $ad_1_pic_address?>" /></a>
        
        </div>