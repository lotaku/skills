<div id="ad_right">
        <a href="<?php echo $ad_4_pic_url?>" ><img src="<?php echo $ad_4_pic_address?>" /></a>
        
        </div>