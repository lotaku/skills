
<a href="ad_del.php">删除广告</a>
<a href="ad_add.php">添加广告</a>
<a href="index.php">返回广告展示页</a>
<a href="logout.php">注销</a>
<?php echo $_SESSION['user']."  已登陆";?>