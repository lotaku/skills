<?php 
session_start();

?>
<?php require_once('Connections/mysql_conn_cs5.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_GET['pic_place_del'])) && ($_GET['pic_place_del'] != "")) {
  $deleteSQL = sprintf("DELETE FROM images WHERE pic_place=%s",
                       GetSQLValueString($_GET['pic_place_del'], "text"));

  mysql_select_db($database_mysql_conn_cs5, $mysql_conn_cs5);
  $Result1 = mysql_query($deleteSQL, $mysql_conn_cs5) or die(mysql_error());
}

$maxRows_Recordset1 = 10;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_mysql_conn_cs5, $mysql_conn_cs5);
$query_Recordset1 = "SELECT * FROM images";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $mysql_conn_cs5) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/css.css"  type="text/css" rel="stylesheet">
<title>无标题文档</title>
</head>

<body>
<h1 align="center"><strong>广告删除页</strong>
<br/> =================</h1>

 <form action="" method="post">
 <table width="491" border="1" align="center">
    <tr>
      <td width="196">广告图片地址</td>
      <td width="96">广告位</td>
      <td width="177">&nbsp;</td>
    </tr>
    <?php do { ?>
      <tr>
        <td><?php echo $row_Recordset1['pic_address']; ?></td>
        <td><?php echo $row_Recordset1['pic_place']; ?></td>
        <td><a href="ad_del.php?pic_place_del=<?php echo $row_Recordset1['pic_place']; ?>">删除</a></td>
      </tr>
      <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
 </table>
 
 </form>
  
 
<div id='admin_menu'   >
<a href="login.php">用户登录</a> 
<?php 
if($_SESSION['user']=='admin')
{	
include ('admin_menu.php');
	}

?>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
