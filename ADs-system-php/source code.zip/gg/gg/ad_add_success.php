<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/css.css"  type="text/css" rel="stylesheet">
<title>无标题文档</title>
</head>

<body>
<div id="ad_add_success">
<h1 align="center">广告添加成功</h1>
 
<div id='admin_menu'   >
<a href="login.php">用户登录</a> 
<?php 
if($_SESSION['user']=='admin')
{	
include ('admin_menu.php');
	}

?>
</div>  
</div>
</body>
</html>